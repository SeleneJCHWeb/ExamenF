﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace FinancieraDatos
{
    public class AppConexion
    {
        public static string CadenaConexion()
        {
            string baseDatos = ConfigurationManager.AppSettings["BaseDatos"];
            string server = ConfigurationManager.AppSettings["Servidor"];
            string usuario = ConfigurationManager.AppSettings["Usuario"];
            string password = ConfigurationManager.AppSettings["Password"];

            string cadenaAuxiliar = $"Server={server}; Database ={baseDatos}; UID ={usuario}; PWD ={password}";
            string cadenaConexion = $"metadata = res://*/FinancieraModel.csdl|res://*/FinancieraModel.ssdl|res://*/FinancieraModel.msl;" +
                $"provider=System.Data.SqlClient;provider connection string='{cadenaAuxiliar}'";

            return cadenaConexion;
        }
    }
}
