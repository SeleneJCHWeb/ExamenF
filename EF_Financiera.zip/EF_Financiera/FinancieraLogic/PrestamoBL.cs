﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FinancieraCore;
using FinancieraDatos;

namespace FinancieraLogic
{
   public class PrestamoBL
    {
        public static List<Prestamo> Listar()
        {
            using (var db = new FinancieraEntities())
            {
                return db.Prestamo.ToList();
            }
        }

        public static Prestamo ObtenerxId(int id)
        {
            using (var db = new FinancieraEntities())
            {
                return db.Prestamo.Find(id);
            }
        }


        public static bool Actualizar(Prestamo prestamo)
        {
            
            using (var db = new FinancieraEntities())
            {
                db.Entry(prestamo).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
                return true;
            }
        }
    }
}
