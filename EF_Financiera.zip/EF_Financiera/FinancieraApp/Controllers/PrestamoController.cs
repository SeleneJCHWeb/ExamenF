﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using FinancieraLogic;
using FinancieraCore;

namespace FinancieraApp.Controllers
{
    public class PrestamoController : Controller
    {
        // GET: Prestamo
        public ActionResult Index()
        {
            var listado = PrestamoBL.Listar();
            return View();
        }


        public ActionResult Listar()
        {
            var listado = PrestamoBL.Listar();
            return View(listado);
        }


        public ActionResult Editar(int id)
        {
            var prestamo = PrestamoBL.ObtenerxId(id);
            ViewBag.Detalles = PrestamoBL.Listar();
            return View(prestamo);
        }


        [HttpPost]
        public ActionResult Editar(Prestamo PrestamoEditar)
        {
            var estado = PrestamoBL.Actualizar(PrestamoEditar);
            if (estado)
                return RedirectToAction("Listar");
            else

            {
                ViewBag.mensaje = "No se ejecutó la operación";
                ViewBag.Detalles = PrestamoBL.Listar();
                return View(PrestamoEditar);
            }
        }



    }
}