﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using FinancieraLogic;



namespace FinancieraApp.Controllers
{
    public class ClienteController : Controller
    {
        // GET: Cliente
        public ActionResult Index()
        {
            var listado = ClienteBL.Listar();
                return View (listado);
        }

    }
}